import { Register } from '../components/Register'

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Register />
    </div>
  )
}

