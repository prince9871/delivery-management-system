import MapComponent from './LocationPicker'

export default function MapPage() {
  return <MapComponent />
}