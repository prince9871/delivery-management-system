import { Routes } from '../components/Routes'

export default function RoutesPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Routes</h1>
      <Routes />
    </div>
  )
}

